#include <stdio.h>
#include<iostream>
#include<stack>
using namespace std;

const int N = 128;

stack<int> stk;
int n, a[N], rmax[N], maxi[N];

int main() {
    scanf("%d", &n);
    for(int i = 0; i < n; ++i) scanf("%d", a+i);
    for(int i = n-1; i >= 0; --i)
        if(rmax[i+1] > a[i]) rmax[i] = rmax[i+1], maxi[i] = maxi[i+1];
        else  rmax[i] = a[i], maxi[i] = i;
    for(int j = 0, i = 0; i < n; ++i) {
        if(stk.empty() || stk.top()<rmax[j])
            for(int k = maxi[j]; j <= k; ++j) stk.push(a[j]);
        printf("%d%c", stk.top(), i<n-1?' ':'\n'), stk.pop();
    }
    return 0;
}

#include <stdio.h>
#define     MAXN    100000
#define     MAXM    60

int n, m, C;
long long label[MAXN];
int power[MAXN], father[MAXN];

void check_and_move(int x, int y) {
    if(!(label[x] & label[y])) return ;
    if(power[x] > power[y]) father[y] = x;
    else if(power[x] < power[y]) father[x] = y;
}
int find(int x) {
    return x == father[x] ? x : father[x] = find(father[x]);
}

int main()
{
    int l, x, y;
    scanf("%d%d%d", &n, &m, &C);
    for(int i = 1; i <= n; i++) {
        scanf("%d%d", &power[i], &l);
        while(l--) {
            scanf("%d", &x);
            label[i] |= (1LL << x);
        }
    }
    for(int i = 1; i <= n; i++) father[i] = i;
    while(C--) {
        scanf("%d%d", &x, &y);
        check_and_move(x, y);
    }
    for(int i = 1; i <= n; i++) printf("%d%c", find(i), i == n ? '\n' : ' ');
    return 0;
}

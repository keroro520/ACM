#include <stdio.h>
#include <algorithm>
using namespace std;
#define     LIMIT       45
class Trie {
    public :
    Trie * children[2];
    Trie () { children[0] = children[1] = NULL; }

    void Insert(long long x, int deep)
    {
        if(deep == -1) return ;
        int t = ((x >> deep) & 1LL);
        if(!children[t]) children[t] = new Trie();
        children[t]->Insert(x, deep-1);
    }

    long long Query(long long x, int deep)
    {
        if(deep == -1) return 0;
        int t = (( x >> deep ) & 1LL);
        if(children[!t]) return (1LL << deep) + children[!t]->Query(x, deep-1);
        else return children[t]->Query(x, deep-1);
        return 0;
    }
};
Trie * root = new Trie();
int n, m;

int main()
{
    long long x;
    scanf("%d%d", &n, &m);
    for(int i = 0; i < n; i++) {
        scanf("%lld", &x);
        root->Insert(x, LIMIT);
    }
    long long ans = 0;
    for(int i = 0; i < m; i++) {
        scanf("%lld", &x);
        ans = max(ans, root->Query(x, LIMIT));
    }
    printf("%lld\n", ans);
    return 0;
}

